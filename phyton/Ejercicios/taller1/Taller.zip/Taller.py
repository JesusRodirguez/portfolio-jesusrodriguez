
while True:
    try:
        NumeroAbsoluto = float(input("Escribe un numero para buscar su valro absoluto : "));
    except:
       print("Error revisa si escribiste un numero");
    if(NumeroAbsoluto >= 0):
        Resultado = int(NumeroAbsoluto)
        print(f"El resultado del valor absoluto {Resultado}");
    else:
        NumeroAbsoluto = NumeroAbsoluto * -1;
        Resultado = int(NumeroAbsoluto)
        print(f"El resultado de tu numero es {Resultado}")
    salida = input("Quieres volver a intentarlo ? si/no :").lower().strip();
    if(salida == "no"):
        print("Hasta luego")
        break
