class persona:
    def __init__(self,nombre,edad):
        self.nombre = nombre;
        self.edad = edad;

class empleado(persona):
    def __init__(self, nombre, edad,ventas,comision,cargo):
        super().__init__(nombre, edad)
        self.ventas = ventas;
        self.cargo = cargo;
        self.comision = comision;

    def MostararComición(self):
        print("=======================================");
        print(f"Nombre      : {self.nombre}")
        print(f"Edad        : {self.edad}")
        print(f"Cargo       : {self.cargo}")
        print(f"VentaAnual  : ${self.ventas:,.2f}")
        print(f"comision    :  ${self.comision:,.2f}")
        print("=======================================");
       


empleados=[];

while True: 
    for i in range(1, 101):  # de 1 a 100
        print(f"\nRegistro del empleado {i}")
        nombre = input("Nombre del empleado: ")
        if not all(x.isalpha() or x.isspace() for x in nombre):
            print("Solo debe de ser letras");
            continue

        cargo = input("Cargo del empleado: ").strip();
        if not all(x.isalpha() or x.isspace() for x in cargo):
            print("Solo debe de ser letras");
            continue
        try:
            ventas = float(input("Ventas realizadas: "))
            edad = int(input("Edad: "))
            if edad < 18 or edad > 70 :
                print("Edad no permitida,no pueden tener esa edad y trabajar aqui");
            
        except ValueError:
            print("Los valores no son los adecuados")
            continue
        if ventas >= 1000000 and ventas < 3000000 :
            comision = (ventas/100)*3;
        elif ventas >= 3000000 and ventas < 5000000 :
            comision = (ventas/100)*4;
        elif ventas >= 5000000 and ventas < 7000000 :
            comision = (ventas/100)*5;
        elif ventas >=7000000 and ventas < 10000000 :
            comision = (ventas/100)*6;
        else :
            print("Revisa lo vendido para darle bien la comisión al usuario")
            continue
 


        emp = empleado(nombre, edad, ventas,comision, cargo)
        empleados.append(emp)

    print("\n✅ Lista completa de empleados ingresados:\n")

    for emp in empleados:
        emp.MostararComición()


    print("===========================")
    total_ventas = sum(emp.ventas for emp in empleados)
    total_comisiones = sum(emp.comision for emp in empleados)
    print(f"Total ventas registradas : ${total_ventas:,.2f}")
    print(f"Total comisiones pagadas : ${total_comisiones:,.2f}")

    salidaWhile = input("Quieres volver a intentarlo? si/no : ").lower();
    if(salidaWhile == "no"):
        print("Hasta luego")
        break