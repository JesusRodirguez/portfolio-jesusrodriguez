import random
class producto:
    def __init__(self,Nombre,precio):
        self.Nombre = Nombre;
        self.precio = precio;
    def CalcularDescuento(self):
        numeroAlazar= random.randint(1,100);
        if(numeroAlazar>=74):
            Desprecio = (self.precio/100)*20;
            precio = self.precio-Desprecio;
            print(f"En tu compra tienes un descuento del 20 %,\n nombre : {self.Nombre},\n precio :  {self.precio} y \n Precio con descuento {precio}")
        elif(numeroAlazar<74):
            Desprecio = (self.precio/100)*15;
            precio = self.precio-Desprecio;
            print(f"En tu compra tienes un descuento del 15 %,\nnombre : {self.Nombre},\n precio :  {self.precio} \n Precio con descuento {precio}")
    def FacturaProducto(self):
        print(f"Feliz dia,\n nombre:  {self.Nombre} \n precio : {self.precio}")
while True:
    try:
        Nombre = input("Bienvenido mi brother\nDame el nombre del producto plis : ").strip();
        if not all(x.isalpha() or x.isspace() for x in Nombre):
            print("Solo debe de ser letras el nombre");
        else:
            precio = float(input("Dame plis,El precio del articulo : "));
            if precio <= 0:
                print("⚠️ El precio debe ser mayor que 0.")
                continue
            persona1 = producto(Nombre,precio);
            RespSuerte = input("¿Quieres probar tu suerte en tu compra ? si/no : ").lower();
            if(RespSuerte == "si"):
                persona1.CalcularDescuento()
            else:
                persona1.FacturaProducto();
            respuesta = input("Quieres volver a intentar si/no ? :").lower();
            if(respuesta =="no"):
                print("Okey hasta luego");
                break
    
    except ValueError:
        print(" Error: el precio debe ser un número.")
    except Exception as e:
        print(f" Ocurrió un error inesperado: {e}")
    


