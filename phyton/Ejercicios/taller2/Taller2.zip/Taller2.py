while True:
    try:
        class producto:
            def __init__(self,Nombre,precio):
                self.Nombre = Nombre;
                self.precio = precio;
            def CalcularDescuento(self,Respuesta):
                if(Respuesta == "si"):
                    clave = float(input("Dame la clave porfavor : "));
                    if(clave == 0.2):
                        precioDescuento = (self.precio/100)*20;
                        precioFinal =self.precio-precioDescuento;
                        print(f"Nombre {self.Nombre},Precio {self.precio} su descuento respectivo de la clave es el 20% {precioFinal}")
                    elif(clave == 0.1):
                        precioDescuento = (self.precio/100)*10;
                        precioFinal = self.precio-precioDescuento;
                        print(f"Nombre {self.Nombre},Precio {self.precio} su descuento respectivo de la clave es el 10% {precioFinal}")

                    else:
                        print("Revisa la clave para los descuentos");
                else:
                    print("Okey, HASTA LUEGO ")
        Nombre = input("Dame el nombre del producto plis : ").strip();
        if not all(x.isalpha() or x.isspace() for x in Nombre):
            print("Solo debe de ser letras el nombre");
        else:
            precio = float(input("Dame plis,El precio del articulo : "));
            Respuesta = input("Quieres hacerle desceunto al producto si/no : ").lower();
            persona1 = producto(Nombre,precio);
            persona1.CalcularDescuento(Respuesta);
    except:
        print("Ocurrió un error: revisa que no hayas dejado campos vacíos o que el precio sea numérico o de texto.")
    
    Answer = input("¿Quieres volver a intentarlo? (si/no): ").lower()

    if Answer == "no":
        print(" Hasta luego, programa terminado.")
        break




 #.strip() sirve para quitar todo los bacios y asi si hacer el if not
     # if not Nombre and precio and Respuesta:
    #     print ("Es necesario mantener todos los campos llenos,para continuar")