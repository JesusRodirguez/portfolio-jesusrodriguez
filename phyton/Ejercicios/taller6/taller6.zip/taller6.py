import random

class persona:
    def __init__(self, DocumentoIdentidad):
        self.DocumentoIdentidad = DocumentoIdentidad

class estudiante(persona):
    def __init__(self, DocumentoIdentidad, nota1, nota2, nota3, notafinal):
        super().__init__(DocumentoIdentidad)
        self.nota1 = nota1
        self.nota2 = nota2
        self.nota3 = nota3
        self.notafinal = notafinal

    def Calificacion(self):
        if self.notafinal >= 3.0 and self.notafinal <= 5.0:
            estado = "Aprobado"
        elif self.notafinal >= 2.0 and self.notafinal <= 2.9:
            estado = "Recuperación"
        else:
            estado = "Perdido"
        
        print("================================================")
        print(f" Documento de identidad :  {self.DocumentoIdentidad}")
        print(f" Nota 1                 :  {self.nota1}")
        print(f" Nota 2                 :  {self.nota2}")
        print(f" Nota 3                 :  {self.nota3}")
        print(f" Nota final             :  {self.notafinal}")
        print(f" Estado                 :  {estado}")
        print("================================================")
        return estado  #  Retorna el estado


while True:
    Respuesta = input("¿Quieres ver la calificación de los 50 estudiantes? si/no: ").lower().strip()
    
    if Respuesta == "si":
        Estudiantes = []
        DocumentoDuplicado = []
        aprobados = 0
        recuperacion = 0
        perdidos = 0
        suma_notas = 0

        #  Generar datos aleatorios
        for i in range(1, 51):
            DocumentoIdentidad = random.randint(100000000000, 199999999999)
            if DocumentoIdentidad in DocumentoDuplicado:
                continue
            DocumentoDuplicado.append(DocumentoIdentidad)

            nota1 = round(random.uniform(1.0, 5.0), 1)
            nota2 = round(random.uniform(1.0, 5.0), 1)
            nota3 = round(random.uniform(1.0, 5.0), 1)
            notafinal = round((nota1 + nota2 + nota3) / 3, 1)

            persona1 = estudiante(DocumentoIdentidad, nota1, nota2, nota3, notafinal)
            Estudiantes.append(persona1)

        print("\n CALIFICACIONES INDIVIDUALES ")
        print("================================================")

        # Mostrar cada estudiante
        for persona1 in Estudiantes:
            estado = persona1.Calificacion()
            suma_notas += persona1.notafinal

            if estado == "Aprobado":
                aprobados += 1
            elif estado == "Recuperación":
                recuperacion += 1
            else:
                perdidos += 1

        # Promedio general del grupo
        promedioGeneral = round(suma_notas / len(Estudiantes), 2)

        print("================================================")
        print(" RESULTADOS GENERALES ")
        print(f" Promedio general del aula : {promedioGeneral}")
        print(f" Aprobados                 : {aprobados}")
        print(f" Recuperación              : {recuperacion}")
        print(f" Perdidos                  : {perdidos}")
        print("================================================")

        #  TOP 3 MEJORES ESTUDIANTES
        print("\n PODIO DE LOS 3 MEJORES ")
        top3 = sorted(Estudiantes, key=lambda x: x.notafinal, reverse=True)[:3]
        for i, estudiante_top in enumerate(top3, start=1):
            print(f" Puesto {i}")
            print(f" Documento: {estudiante_top.DocumentoIdentidad}")
            print(f" Nota 1    : {estudiante_top.nota1}")
            print(f" Nota 2    : {estudiante_top.nota2}")
            print(f" Nota 3    : {estudiante_top.nota3}")
            print(f" Nota final: {estudiante_top.notafinal}")
            print("------------------------------------------------")

    elif Respuesta == "no":
        print("Okey, hasta luego mi brother ")
        break
    else:
        print("Solo se permite si/no mi brother")
        continue

    SalidaWhile = input("¿Quieres volverlo a intentar si/no?: ").lower().strip()
    if SalidaWhile == "no":
        print("Hasta luego mi brother 👋")
        break
