# ---------------------------------------
# RETO No.2 - Operaciones Aritméticas en Python
# Autor: RodriguezPerezJesusDavid
# Fecha: 03/10/2025
# ---------------------------------------

def suma(a, b):
    return a + b

def resta(a, b):
    return a - b

def multiplicacion(a, b):
    return a * b

def division(a, b):
    if b != 0:
        return a / b
    else:
        return "No se puede dividir entre cero"

def area_cuadrado(lado):
    return lado * lado

def area_triangulo(base, altura):
    return (base * altura) / 2

def area_rectangulo(base, altura):
    return base * altura

def area_circulo(radio):
    from math import pi
    return pi * (radio ** 2)

# ---------------------------------------
# MENÚ PRINCIPAL
# ---------------------------------------
while True:
    print("\n MENÚ DE OPERACIONES ARITMÉTICAS ")
    print("1 Suma (A + B)")
    print("2 Resta (A - B)")
    print("3 Multiplicación (A * B)")
    print("4 División (A / B)")
    print("5 Área de un Cuadrado")
    print("6 Área de un Triángulo")
    print("7 Área de un Rectángulo")
    print("8 Área de un Círculo")
    print("9 Salir")

    opcion = input("Seleccione una opción: ")

    if opcion == "1":
        a = float(input("Ingrese A: "))
        b = float(input("Ingrese B: "))
        print(f"Resultado: {suma(a, b)}")

    elif opcion == "2":
        a = float(input("Ingrese A: "))
        b = float(input("Ingrese B: "))
        print(f"Resultado: {resta(a, b)}")

    elif opcion == "3":
        a = float(input("Ingrese A: "))
        b = float(input("Ingrese B: "))
        print(f"Resultado: {multiplicacion(a, b)}")

    elif opcion == "4":
        a = float(input("Ingrese A: "))
        b = float(input("Ingrese B: "))
        print(f"Resultado: {division(a, b)}")

    elif opcion == "5":
        lado = float(input("Ingrese el lado del cuadrado: "))
        print(f"Área del cuadrado: {area_cuadrado(lado)}")

    elif opcion == "6":
        base = float(input("Ingrese la base: "))
        altura = float(input("Ingrese la altura: "))
        print(f"Área del triángulo: {area_triangulo(base, altura)}")

    elif opcion == "7":
        base = float(input("Ingrese la base: "))
        altura = float(input("Ingrese la altura: "))
        print(f"Área del rectángulo: {area_rectangulo(base, altura)}")

    elif opcion == "8":
        radio = float(input("Ingrese el radio: "))
        print(f"Área del círculo: {area_circulo(radio)}")

    elif opcion == "9":
        print(" Saliendo del programa... ¡Hasta luego!")
        break

    else:
        print(" Opción no válida. Intente nuevamente.")
