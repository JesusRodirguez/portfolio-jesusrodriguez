import random
class NUMERO:
    def __init__(self,numero,numeroExponente):
        self.numero = numero
        self.numeroExponente = numeroExponente
    def Mostrarnumero(self):
        print("================================================")
        print(f"   Numero  :     {self.numero}")
        print(f" Numero**2 :     {self.numeroExponente}")
        print("================================================")

Numeros=[]
NumerosUsados = []
while True:

    Answer = input("¿Quieres que te de 500 numeros y luego elevados en arrays? si/no : ").lower().strip()
    if(Answer == "si"):
        for i in range(1,501):
            # numero random
            numero = random.randint(1,501)
            if numero in NumerosUsados:
                continue

            numeroExponente = pow(numero,2)
            persona = NUMERO(numero,numeroExponente);
            Numeros.append(persona);
            NumerosUsados.append(numero);

        for n in Numeros:
            n.Mostrarnumero()
            maximo = max(NumerosUsados)
            minimo = min(NumerosUsados)

    elif(Answer == "no"):
        print("Hasta luego mi brother")
        break

    else:
        print("Solo se permite si o no")
        continue
    


    respuestawhile = input("¿Quieres volver a intentar ? si/no : ").lower()
    if(respuestawhile == "no"):
        print("Hasta luego");
        break