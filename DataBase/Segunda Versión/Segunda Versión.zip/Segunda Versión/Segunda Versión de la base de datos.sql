-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-09-2025 a las 18:32:22
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `midnightcode`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarUsuarioPorDocumento` (IN `doc` INT)   BEGIN
    SELECT *
    FROM usuarios
    WHERE documento = doc;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_factura_log` (IN `p_cod_factura` INT, IN `p_documento` INT, IN `p_fecha_inicio` DATETIME, IN `p_fecha_fin` DATETIME)   BEGIN
    SELECT *
    FROM factura_log
    WHERE (p_cod_factura IS NULL OR cod_factura = p_cod_factura)
      AND (p_documento IS NULL OR documento = p_documento)
      AND fecha_accion BETWEEN p_fecha_inicio AND p_fecha_fin
    ORDER BY fecha_accion DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_historial_reserva` (IN `p_cod_reserva` INT)   BEGIN
    SELECT id_log, cod_reserva, accion, 
           old_documento, old_tipo, old_estado, 
           new_documento, new_tipo, new_estado, 
           fecha_accion
    FROM reservas_log
    WHERE cod_reserva = p_cod_reserva
    ORDER BY fecha_accion DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_horario` (IN `p_cod_horario` INT)   BEGIN
    SELECT h.cod_horario, h.fecha, h.hora, h.nombre_trabajador, h.cargo, h.horas_trabajo,
           u.nom_usu AS nombre_usuario, u.email, u.cod_rol
    FROM horario h
    INNER JOIN usuarios u ON h.documento = u.documento
    WHERE h.cod_horario = p_cod_horario;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_horario_documento` (IN `p_documento` INT)   BEGIN
    SELECT h.cod_horario, h.fecha, h.hora, h.nombre_trabajador, h.cargo, h.horas_trabajo,
           u.nom_usu AS nombre_usuario, u.email, u.cod_rol
    FROM horario h
    INNER JOIN usuarios u ON h.documento = u.documento
    WHERE h.documento = p_documento
    ORDER BY h.fecha, h.hora;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_logs` (IN `p_entidad` ENUM('venta','inventario','producto','reserva','gestion_usuario'), IN `p_cod_registro` INT, IN `p_documento` INT, IN `p_fecha_inicio` DATETIME, IN `p_fecha_fin` DATETIME)   BEGIN
    CASE p_entidad
        WHEN 'venta' THEN
            SELECT *
            FROM venta_log
            WHERE (p_cod_registro IS NULL OR cod_venta = p_cod_registro)
              AND (p_documento IS NULL OR documento = p_documento)
              AND fecha_accion BETWEEN p_fecha_inicio AND p_fecha_fin
            ORDER BY fecha_accion DESC;

        WHEN 'inventario' THEN
            SELECT *
            FROM inventario_log
            WHERE (p_cod_registro IS NULL OR cod_inventario = p_cod_registro)
              AND (p_documento IS NULL OR documento = p_documento)
              AND fecha_accion BETWEEN p_fecha_inicio AND p_fecha_fin
            ORDER BY fecha_accion DESC;

        WHEN 'producto' THEN
            SELECT *
            FROM producto_log
            WHERE (p_cod_registro IS NULL OR cod_producto = p_cod_registro)
              AND (p_documento IS NULL OR documento = p_documento)
              AND fecha_accion BETWEEN p_fecha_inicio AND p_fecha_fin
            ORDER BY fecha_accion DESC;

        WHEN 'reserva' THEN
            SELECT *
            FROM reserva_log
            WHERE (p_cod_registro IS NULL OR cod_reserva = p_cod_registro)
              AND (p_documento IS NULL OR documento = p_documento)
              AND fecha_accion BETWEEN p_fecha_inicio AND p_fecha_fin
            ORDER BY fecha_accion DESC;

        WHEN 'gestion_usuario' THEN
            SELECT *
            FROM gestion_usuario
            WHERE (p_cod_registro IS NULL OR documento_new = p_cod_registro OR documento_old = p_cod_registro)
              AND (p_documento IS NULL OR usuario_new = p_documento OR usuario_old = p_documento)
              AND fecha_modificacion BETWEEN p_fecha_inicio AND p_fecha_fin
            ORDER BY fecha_modificacion DESC;
    END CASE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_logs_facturalog` (IN `p_entidad` ENUM('venta','inventario','producto','reserva','gestion_usuario','factura'), IN `p_cod_registro` INT, IN `p_documento` INT, IN `p_fecha_inicio` DATETIME, IN `p_fecha_fin` DATETIME)   BEGIN
    CASE p_entidad
        WHEN 'venta' THEN
            SELECT *
            FROM venta_log
            WHERE (p_cod_registro IS NULL OR cod_venta = p_cod_registro)
              AND (p_documento IS NULL OR documento = p_documento)
              AND fecha_accion BETWEEN p_fecha_inicio AND p_fecha_fin
            ORDER BY fecha_accion DESC;

        WHEN 'inventario' THEN
            SELECT *
            FROM inventario_log
            WHERE (p_cod_registro IS NULL OR cod_inventario = p_cod_registro)
              AND (p_documento IS NULL OR documento = p_documento)
              AND fecha_accion BETWEEN p_fecha_inicio AND p_fecha_fin
            ORDER BY fecha_accion DESC;

        WHEN 'producto' THEN
            SELECT *
            FROM producto_log
            WHERE (p_cod_registro IS NULL OR cod_producto = p_cod_registro)
              AND (p_documento IS NULL OR documento = p_documento)
              AND fecha_accion BETWEEN p_fecha_inicio AND p_fecha_fin
            ORDER BY fecha_accion DESC;

        WHEN 'reserva' THEN
            SELECT *
            FROM reserva_log
            WHERE (p_cod_registro IS NULL OR cod_reserva = p_cod_registro)
              AND (p_documento IS NULL OR documento = p_documento)
              AND fecha_accion BETWEEN p_fecha_inicio AND p_fecha_fin
            ORDER BY fecha_accion DESC;

        WHEN 'gestion_usuario' THEN
            SELECT *
            FROM gestion_usuario
            WHERE (p_cod_registro IS NULL OR documento_new = p_cod_registro OR documento_old = p_cod_registro)
              AND (p_documento IS NULL OR usuario_new = p_documento OR usuario_old = p_documento)
              AND fecha_modificacion BETWEEN p_fecha_inicio AND p_fecha_fin
            ORDER BY fecha_modificacion DESC;

        WHEN 'factura' THEN
            SELECT *
            FROM factura_log
            WHERE (p_cod_registro IS NULL OR cod_factura = p_cod_registro)
              AND (p_documento IS NULL OR documento = p_documento)
              AND fecha_accion BETWEEN p_fecha_inicio AND p_fecha_fin
            ORDER BY fecha_accion DESC;
    END CASE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_producto` (IN `p_cod_producto` INT)   BEGIN
    SELECT *
    FROM vw_producto_usuario
    WHERE cod_producto = p_cod_producto;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_reserva` (IN `p_cod_reserva` INT)   BEGIN
    SELECT r.cod_reserva, r.Hora_Fecha, r.tipo, r.estado,
           u.nombre_usu, u.correo,u.telefono
    FROM reservas r
    INNER JOIN usuarios u ON r.documento = u.documento
    WHERE r.cod_reserva = p_cod_reserva;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_venta` (IN `p_cod_venta` INT)   BEGIN
    SELECT *
    FROM vw_ventas_inventario v
    WHERE v.cod_venta = p_cod_venta;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_generar_factura` (IN `p_cod_venta` INT)   BEGIN
    DECLARE v_documento INT;
    DECLARE v_subtotal DECIMAL(12,4);
    DECLARE v_total DECIMAL(10,2);

    -- Obtener datos de la venta
    SELECT documento, subtotal, total
    INTO v_documento, v_subtotal, v_total
    FROM ventas
    WHERE cod_venta = p_cod_venta;

    -- Insertar en factura
    INSERT INTO factura (cod_venta, documento, subtotal, total)
    VALUES (p_cod_venta, v_documento, v_subtotal, v_total);

    -- Devolver la factura generada
    SELECT *
    FROM factura
    WHERE cod_factura = LAST_INSERT_ID();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_historial_horario` (IN `p_documento` INT)   BEGIN
    SELECT 
        id_log,
        cod_horario,
        documento,
        fecha, hora, nombre_trabajador, cargo, horas_trabajo,
        fecha_anterior, hora_anterior, nombre_trabajador_anterior,  cargo_anterior, horas_trabajo_anterior,
        accion,
        fecha_accion
    FROM horario_log
    WHERE documento = p_documento
    ORDER BY fecha_accion DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_historial_producto` (IN `p_cod_producto` INT)   BEGIN
    SELECT 
        cod_productolog,
        cod_producto,
        nombre_prod,
        categoria,
        precio,
        documento,
        cantidad_producto,
        Descripción_producto,
        nombre_prod_anterior,
        categoria_anterior,
        precio_anterior,
        documento_anterior,
        Descripción_producto_anterior,
        accion,
        fecha_accion
    FROM producto_log
    WHERE cod_producto = p_cod_producto
    ORDER BY fecha_accion DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_historial_usuario` (IN `p_documento` INT)   BEGIN
    SELECT fecha_modificacion,
           documento_old, documento_new,
           nom_usuold, nom_usunew,
           usuario_old, usuario_new,
           correo_old, correo_new,
           contrasena_old, contrasena_new,
           telefono_old, telefono_new,
           cod_rolold, cod_rolnew
    FROM gestion_usu
    WHERE documento_old = p_documento OR documento_new = p_documento
    ORDER BY fecha_modificacion DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_horario_completo` (IN `p_documento` INT)   BEGIN
    -- 1️⃣ Mostrar horarios actuales
    SELECT 
        h.cod_horario,
        h.fecha,
        h.hora,
        h.nombre_trabajador,
        h.telefono,
        h.cargo,
        h.horas_trabajo,
        u.nom_usu AS nombre_usuario,
        u.email,
        u.cod_rol
    FROM horario h
    INNER JOIN usuarios u ON h.documento = u.documento
    WHERE h.documento = p_documento
    ORDER BY h.fecha, h.hora;

    -- 2️⃣ Mostrar historial de cambios
    SELECT 
        id_log,
        cod_horario,
        documento,
        fecha, hora, nombre_trabajador, cargo, horas_trabajo,
        fecha_anterior, hora_anterior, nombre_trabajador_anterior,  cargo_anterior, horas_trabajo_anterior,
        accion,
        fecha_accion
    FROM horario_log
    WHERE documento = p_documento
    ORDER BY fecha_accion DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_inventario_completo` (IN `p_cod_producto` INT, IN `p_cantidad_producto` INT, IN `p_documento` INT)   BEGIN
    -- 1️⃣ Registrar la cantidad en inventario
    INSERT INTO inventario (cod_producto, cantidad_producto, documento)
    VALUES (p_cod_producto, p_cantidad_producto, p_documento);

    -- 2️⃣ Mostrar el registro con datos de producto y usuario
    SELECT *
    FROM vw_inventario_producto_usuario
    WHERE cod_inventario = LAST_INSERT_ID();

    -- 3️⃣ Mostrar historial completo del inventario
    SELECT 
        cod_inventariolog,
        cod_inventario,
        cod_producto,
        cantidad_producto,
        documento,
        cantidad_producto_anterior,
        documento_anterior,
        accion,
        fecha_accion
    FROM inventario_log
    WHERE cod_inventario = LAST_INSERT_ID()
    ORDER BY fecha_accion DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_reservas_usuario` (IN `p_documento` INT)   BEGIN
    SELECT cod_reserva, Hora_Fecha, tipo, estado
    FROM reservas
    WHERE documento = p_documento;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_ventas` (IN `p_fecha_inicio` DATETIME, IN `p_fecha_fin` DATETIME)   BEGIN
    SELECT *
    FROM vw_ventas_inventario v
    WHERE v.fecha BETWEEN p_fecha_inicio AND p_fecha_fin
    ORDER BY v.fecha DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_horario` (IN `p_documento` INT, IN `p_fecha` DATE, IN `p_hora` TIME, IN `p_nombre_trabajador` VARCHAR(100), IN `p_cargo` ENUM('Administrador','Empleado','Supervisor'), IN `p_horas_trabajo` DECIMAL(4,2))   BEGIN
    INSERT INTO horario (documento, fecha, hora, nombre_trabajador, telefono, cargo, horas_trabajo)
    VALUES (p_documento, p_fecha, p_hora, p_nombre_trabajador, p_telefono, p_cargo, p_horas_trabajo);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_reserva` (IN `p_documento` INT, IN `p_tipo` ENUM('Mesa Vip','Mesa','Cover','Parqueadero'), IN `p_estado` ENUM('Pendiente','Cancelado','Exitoso'))   BEGIN
    INSERT INTO reservas (documento, tipo, estado)
    VALUES (p_documento, p_tipo, p_estado);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_venta` (IN `p_documento` INT, IN `p_cod_inventario` INT, IN `p_cod_reserva` INT, IN `p_cantidad_venta` INT, IN `p_subtotal` DECIMAL(12,4), IN `p_total` DECIMAL(10,2))   BEGIN
    -- 1️⃣ Insertar la venta
    INSERT INTO ventas (documento, cod_inventario, cod_reserva, cantidad_venta, subtotal, total)
    VALUES (p_documento, p_cod_inventario, p_cod_reserva, p_cantidad_venta, p_subtotal, p_total);

    -- 2️⃣ Actualizar la reserva si corresponde
    IF p_cod_reserva IS NOT NULL THEN
        UPDATE reservas
        SET estado = 'Exitoso'
        WHERE cod_reserva = p_cod_reserva;
    END IF;

    -- 3️⃣ Descontar la cantidad del inventario
    UPDATE inventario
    SET cantidad_producto = cantidad_producto - p_cantidad_venta
    WHERE cod_inventario = p_cod_inventario;

    -- 4️⃣ Devolver la venta registrada con todos los datos de la vista
    SELECT *
    FROM vw_ventas_inventario v
    WHERE v.cod_venta = LAST_INSERT_ID();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_venta_factura` (IN `p_documento` INT, IN `p_cod_inventario` INT, IN `p_cod_reserva` INT, IN `p_cantidad_venta` INT, IN `p_subtotal` DECIMAL(12,4), IN `p_total` DECIMAL(10,2))   BEGIN
    DECLARE v_cod_venta INT;
    DECLARE v_cod_factura INT;

    -- 1️⃣ Insertar la venta
    INSERT INTO ventas (documento, cod_inventario, cod_reserva, cantidad_venta, subtotal, total)
    VALUES (p_documento, p_cod_inventario, p_cod_reserva, p_cantidad_venta, p_subtotal, p_total);

    SET v_cod_venta = LAST_INSERT_ID();

    -- 2️⃣ Actualizar la reserva si corresponde
    IF p_cod_reserva IS NOT NULL THEN
        UPDATE reservas
        SET estado = 'Exitoso'
        WHERE cod_reserva = p_cod_reserva;
    END IF;

    -- 3️⃣ Descontar la cantidad del inventario
    UPDATE inventario
    SET cantidad_producto = cantidad_producto - p_cantidad_venta
    WHERE cod_inventario = p_cod_inventario;

    -- 4️⃣ Generar la factura automáticamente
    INSERT INTO factura (cod_venta, documento, subtotal, total)
    SELECT v_cod_venta, p_documento, p_subtotal, p_total;

    SET v_cod_factura = LAST_INSERT_ID();

    -- 5️⃣ Devolver la venta y la factura recién generadas
    SELECT *
    FROM vw_ventas_inventario
    WHERE cod_venta = v_cod_venta;

    SELECT *
    FROM factura
    WHERE cod_factura = v_cod_factura;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_y_listar_horario` (IN `p_documento` INT, IN `p_fecha` DATE, IN `p_hora` TIME, IN `p_nombre_trabajador` VARCHAR(100), IN `p_telefono` VARCHAR(15), IN `p_cargo` ENUM('Administrador','Empleado','Supervisor'), IN `p_horas_trabajo` DECIMAL(4,2))   BEGIN
    -- 1️⃣ Registrar el nuevo horario
    INSERT INTO horario (documento, fecha, hora, nombre_trabajador, telefono, cargo, horas_trabajo)
    VALUES (p_documento, p_fecha, p_hora, p_nombre_trabajador, p_telefono, p_cargo, p_horas_trabajo);

    -- 2️⃣ Listar todos los horarios del trabajador
    SELECT h.cod_horario, h.fecha, h.hora, h.nombre_trabajador, h.telefono, h.cargo, h.horas_trabajo,
           u.nom_usu AS nombre_usuario, u.email, u.cod_rol
    FROM horario h
    INNER JOIN usuarios u ON h.documento = u.documento
    WHERE h.documento = p_documento
    ORDER BY h.fecha, h.hora;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_y_mostrar_inventario` (IN `p_cod_producto` INT, IN `p_cantidad_producto` INT, IN `p_documento` INT)   BEGIN
    -- 1️⃣ Registrar la cantidad en inventario
    INSERT INTO inventario (cod_producto, cantidad_producto, documento)
    VALUES (p_cod_producto, p_cantidad_producto, p_documento);

    -- 2️⃣ Mostrar el registro con datos de producto y usuario
    SELECT *
    FROM vw_inventario_producto_usuario
    WHERE cod_inventario = LAST_INSERT_ID();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_y_mostrar_producto` (IN `p_nombre_prod` VARCHAR(100), IN `p_categoria` VARCHAR(50), IN `p_precio` DECIMAL(10,2), IN `p_documento` INT, IN `p_Descripción_producto` VARCHAR(200))   BEGIN
    -- 1️⃣ Registrar el producto
    INSERT INTO producto (nombre_prod, categoria, precio, documento, Descripción_producto)
    VALUES (p_nombre_prod, p_categoria, p_precio, p_documento, p_Descripción_producto);

    -- 2️⃣ Mostrar el producto registrado con los datos del usuario
    SELECT *
    FROM vw_producto_usuario
    WHERE cod_producto = LAST_INSERT_ID();
    -- 3️⃣ Mostrar historial completo del producto
    SELECT 
        id_log,
        cod_producto,
        nombre_prod,
        categoria,
        precio,
        documento,
        Descripción_producto,
        nombre_prod_anterior,
        categoria_anterior,
        precio_anterior,
        documento_anterior,
        Descripción_producto_anterior,
        accion,
        fecha_accion
    FROM producto_log
    WHERE cod_producto = LAST_INSERT_ID()
    ORDER BY fecha_accion DESC;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `cod_factura` int(12) NOT NULL,
  `cod_venta` int(12) NOT NULL,
  `documento` int(12) NOT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `subtotal` decimal(12,4) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `estado` enum('Emitida','Pagada','Anulada') DEFAULT 'Emitida'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Disparadores `factura`
--
DELIMITER $$
CREATE TRIGGER `trg_factura_after_insert` AFTER INSERT ON `factura` FOR EACH ROW BEGIN
    INSERT INTO factura_log (cod_factura, cod_venta, documento, subtotal, total, estado, accion)
    VALUES (NEW.cod_factura, NEW.cod_venta, NEW.documento, NEW.subtotal, NEW.total, NEW.estado, 'INSERT');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_factura_before_delete` BEFORE DELETE ON `factura` FOR EACH ROW BEGIN
    INSERT INTO factura_log (
        cod_factura,
        cod_venta,
        documento,
        subtotal,
        total,
        estado,
        accion
    )
    VALUES (
        OLD.cod_factura,
        OLD.cod_venta,
        OLD.documento,
        OLD.subtotal,
        OLD.total,
        OLD.estado,
        'DELETE'
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_factura_before_update` BEFORE UPDATE ON `factura` FOR EACH ROW BEGIN
    INSERT INTO factura_log (
        cod_factura,
        cod_venta,
        documento,
        subtotal,
        total,
        estado,
        accion,
        subtotal_anterior,
        total_anterior,
        estado_anterior
    )
    VALUES (
        OLD.cod_factura,
        OLD.cod_venta,
        OLD.documento,
        OLD.subtotal,
        OLD.total,
        OLD.estado,
        'UPDATE',
        OLD.subtotal,
        OLD.total,
        OLD.estado
    );
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura_log`
--

CREATE TABLE `factura_log` (
  `cod_facturalog` int(12) NOT NULL,
  `cod_factura` int(12) DEFAULT NULL,
  `cod_venta` int(12) DEFAULT NULL,
  `documento` int(12) DEFAULT NULL,
  `subtotal` decimal(12,4) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `estado` enum('Emitida','Pagada','Anulada') DEFAULT NULL,
  `accion` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `fecha_accion` timestamp NOT NULL DEFAULT current_timestamp(),
  `subtotal_anterior` decimal(12,4) DEFAULT NULL,
  `total_anterior` decimal(10,2) DEFAULT NULL,
  `estado_anterior` enum('Emitida','Pagada','Anulada') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gestion_usu`
--

CREATE TABLE `gestion_usu` (
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `documento_old` int(12) NOT NULL,
  `documento_new` int(12) NOT NULL,
  `nom_usuold` varchar(100) NOT NULL,
  `nom_usunew` varchar(100) NOT NULL,
  `usuario_old` varchar(50) NOT NULL,
  `usuario_new` varchar(50) NOT NULL,
  `correo_old` varchar(100) NOT NULL,
  `correo_new` varchar(100) NOT NULL,
  `contrasena_old` varchar(100) NOT NULL,
  `contrasena_new` varchar(100) NOT NULL,
  `telefono_old` varchar(15) NOT NULL,
  `telefono_new` varchar(100) NOT NULL,
  `cod_rolold` int(12) NOT NULL,
  `cod_rolnew` int(12) NOT NULL,
  `documento` int(12) NOT NULL,
  `cod-gestionusu` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horario`
--

CREATE TABLE `horario` (
  `cod_horario` int(12) NOT NULL,
  `documento` int(12) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `nombre_trabajador` varchar(100) NOT NULL,
  `cargo` enum('Administrador','Cantinero','DJ','Cajero','Jalador','Portero','Mesero') NOT NULL,
  `horas_trabajo` decimal(4,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Disparadores `horario`
--
DELIMITER $$
CREATE TRIGGER `trg_horario_delete` AFTER DELETE ON `horario` FOR EACH ROW BEGIN
    INSERT INTO horario_log (
        cod_horario, documento, fecha, hora, nombre_trabajador,  cargo, horas_trabajo, accion
    ) VALUES (
        OLD.cod_horario, OLD.documento, OLD.fecha, OLD.hora, OLD.nombre_trabajador,  OLD.cargo, OLD.horas_trabajo, 'DELETE'
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_horario_insert` AFTER INSERT ON `horario` FOR EACH ROW BEGIN
    INSERT INTO horario_log (
        cod_horario, documento, fecha, hora, nombre_trabajador, cargo, horas_trabajo, accion
    ) VALUES (
        NEW.cod_horario, NEW.documento, NEW.fecha, NEW.hora, NEW.nombre_trabajador, NEW.cargo, NEW.horas_trabajo, 'INSERT'
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_horario_update` AFTER UPDATE ON `horario` FOR EACH ROW BEGIN
    INSERT INTO horario_log (
        cod_horario, documento,
        fecha, hora, nombre_trabajador, telefono, cargo, horas_trabajo,
        fecha_anterior, hora_anterior, nombre_trabajador_anterior, telefono_anterior, cargo_anterior, horas_trabajo_anterior,
        accion
    ) VALUES (
        NEW.cod_horario, NEW.documento,
        NEW.fecha, NEW.hora, NEW.nombre_trabajador,  NEW.cargo, NEW.horas_trabajo,
        OLD.fecha, OLD.hora, OLD.nombre_trabajador,  OLD.cargo, OLD.horas_trabajo,
        'UPDATE'
    );
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horario_log`
--

CREATE TABLE `horario_log` (
  `cod_horariolog` int(12) NOT NULL,
  `cod_horario` int(12) DEFAULT NULL,
  `documento` int(12) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `nombre_trabajador` varchar(100) DEFAULT NULL,
  `cargo` enum('Administrador','Empleado','Supervisor') DEFAULT NULL,
  `horas_trabajo` decimal(4,2) DEFAULT NULL,
  `accion` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `fecha_accion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_anterior` date DEFAULT NULL,
  `hora_anterior` time DEFAULT NULL,
  `nombre_trabajador_anterior` varchar(100) DEFAULT NULL,
  `cargo_anterior` enum('Administrador','Empleado','Supervisor') DEFAULT NULL,
  `horas_trabajo_anterior` decimal(4,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `cod_inventario` int(12) NOT NULL,
  `cod_producto` int(12) DEFAULT NULL,
  `cantidad_producto` int(3) NOT NULL,
  `documento` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Disparadores `inventario`
--
DELIMITER $$
CREATE TRIGGER `trg_inventario_delete` AFTER DELETE ON `inventario` FOR EACH ROW BEGIN
    INSERT INTO inventario_log (
        cod_inventario, cod_producto, cantidad_producto, documento, accion
    ) VALUES (
        OLD.cod_inventario, OLD.cod_producto, OLD.cantidad_producto, OLD.documento, 'DELETE'
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_inventario_insert` AFTER INSERT ON `inventario` FOR EACH ROW BEGIN
    INSERT INTO inventario_log (
        cod_inventario, cod_producto, cantidad_producto, documento, accion
    ) VALUES (
        NEW.cod_inventario, NEW.cod_producto, NEW.cantidad_producto, NEW.documento, 'INSERT'
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_inventario_update` AFTER UPDATE ON `inventario` FOR EACH ROW BEGIN
    INSERT INTO inventario_log (
        cod_inventario,
        cod_producto,
        cantidad_producto,
        documento,
        cantidad_producto_anterior,
        documento_anterior,
        accion
    ) VALUES (
        NEW.cod_inventario,
        NEW.cod_producto,
        NEW.cantidad_producto,
        NEW.documento,
        OLD.cantidad_producto,
        OLD.documento,
        'UPDATE'
    );
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario_log`
--

CREATE TABLE `inventario_log` (
  `cod_inventariolog` int(12) NOT NULL,
  `cod_inventario` int(12) DEFAULT NULL,
  `cod_producto` int(12) DEFAULT NULL,
  `cantidad_producto` int(3) DEFAULT NULL,
  `documento` int(12) DEFAULT NULL,
  `accion` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `fecha_accion` timestamp NOT NULL DEFAULT current_timestamp(),
  `cantidad_producto_anterior` int(3) DEFAULT NULL,
  `documento_anterior` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `cod_producto` int(12) NOT NULL,
  `nombre_prod` varchar(100) NOT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `documento` int(12) NOT NULL,
  `Descripción_producto` varchar(200) NOT NULL,
  `cantidad_producto` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Disparadores `productos`
--
DELIMITER $$
CREATE TRIGGER `trg_producto_delete` AFTER DELETE ON `productos` FOR EACH ROW BEGIN
    INSERT INTO producto_log (
        cod_producto, nombre_prod, categoria, precio, documento, Descripción_producto, accion
    ) VALUES (
        OLD.cod_producto, OLD.nombre_prod, OLD.categoria, OLD.precio, OLD.documento, OLD.Descripción_producto, 'DELETE'
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_producto_insert` AFTER INSERT ON `productos` FOR EACH ROW BEGIN
    INSERT INTO producto_log (
        cod_producto, nombre_prod, categoria, precio, documento, Descripción_producto, accion
    ) VALUES (
        NEW.cod_producto, NEW.nombre_prod, NEW.categoria, NEW.precio, NEW.documento, NEW.Descripción_producto, 'INSERT'
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_producto_update` AFTER UPDATE ON `productos` FOR EACH ROW BEGIN
    INSERT INTO producto_log (
        cod_producto,
        nombre_prod, categoria, precio, documento, Descripción_producto,
        nombre_prod_anterior, categoria_anterior, precio_anterior, documento_anterior, Descripción_producto_anterior,
        accion
    ) VALUES (
        NEW.cod_producto,
        NEW.nombre_prod, NEW.categoria, NEW.precio, NEW.documento, NEW.Descripción_producto,
        OLD.nombre_prod, OLD.categoria, OLD.precio, OLD.documento, OLD.Descripción_producto,
        'UPDATE'
    );
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto_log`
--

CREATE TABLE `producto_log` (
  `cod_productolog` int(12) NOT NULL,
  `cod_producto` int(12) DEFAULT NULL,
  `nombre_prod` varchar(100) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `documento` int(12) DEFAULT NULL,
  `Descripción_producto` varchar(200) DEFAULT NULL,
  `accion` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `fecha_accion` timestamp NOT NULL DEFAULT current_timestamp(),
  `nombre_prod_anterior` varchar(100) DEFAULT NULL,
  `categoria_anterior` varchar(50) DEFAULT NULL,
  `precio_anterior` decimal(10,2) DEFAULT NULL,
  `documento_anterior` int(12) DEFAULT NULL,
  `Descripción_producto_anterior` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE `reservas` (
  `cod_reserva` int(12) NOT NULL,
  `documento` int(12) NOT NULL,
  `Hora_Fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tipo` enum('Mesa Vip','Mesa','Cover','Parqueadero') NOT NULL,
  `estado` enum('Exitoso','Pendiente','Cancelado','') NOT NULL DEFAULT 'Pendiente',
  `precio` decimal(10,4) NOT NULL,
  `cantidad` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Disparadores `reservas`
--
DELIMITER $$
CREATE TRIGGER `trg_reservas_delete` AFTER DELETE ON `reservas` FOR EACH ROW BEGIN
    INSERT INTO reservas_log (cod_reserva, documento, Hora_Fecha, tipo, estado, accion)
    VALUES (OLD.cod_reserva, OLD.documento, OLD.Hora_Fecha, OLD.tipo, OLD.estado, 'DELETE');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_reservas_insert` AFTER INSERT ON `reservas` FOR EACH ROW BEGIN
    INSERT INTO reservas_log (cod_reserva, documento, Hora_Fecha, tipo, estado, accion)
    VALUES (NEW.cod_reserva, NEW.documento, NEW.Hora_Fecha, NEW.tipo, NEW.estado, 'INSERT');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_reservas_update` AFTER UPDATE ON `reservas` FOR EACH ROW BEGIN
    INSERT INTO reservas_log (cod_reserva, documento, Hora_Fecha, tipo, estado, accion)
    VALUES (NEW.cod_reserva, NEW.documento, NEW.Hora_Fecha, NEW.tipo, NEW.estado, 'UPDATE');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas_log`
--

CREATE TABLE `reservas_log` (
  `cod_reservalog` int(12) NOT NULL,
  `cod_reserva` int(12) NOT NULL,
  `documento` int(12) NOT NULL,
  `Hora_Fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `tipo` enum('Mesa Vip','Mesa','Cover','Parqueadero') DEFAULT NULL,
  `estado` enum('Exitoso','Pendiente','Cancelado','') DEFAULT NULL,
  `accion` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `fecha_accion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `cod_rol` int(12) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `rol` enum('Administrador','Empleado_Autoriza','Empleado','Cliente') NOT NULL,
  `Descrip_rol` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`cod_rol`, `nombre`, `rol`, `Descrip_rol`) VALUES
(121212, 'Empleado', 'Empleado', 'Trabajador del establecimiento'),
(232323, 'Empleado Autorizado', 'Empleado_Autoriza', 'El segundo al mando puede tener gestión en diferentes campo como el administrador pero no todos.'),
(676767, 'Cliente', 'Cliente', 'Es el  rol predeterminado para el usuario'),
(787878, 'Administrador', 'Administrador', 'Es el rol con más permisos en el sistema');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `documento` int(12) NOT NULL,
  `nombre_usu` varchar(100) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contrasena` varchar(100) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `cod_rol` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`documento`, `nombre_usu`, `usuario`, `correo`, `contrasena`, `telefono`, `cod_rol`) VALUES
(12345678, 'adsassda', 'juan_asda', 'asdssa', '123wqe', '32123344543', 676767);

--
-- Disparadores `usuarios`
--
DELIMITER $$
CREATE TRIGGER `before_insertusuario` BEFORE INSERT ON `usuarios` FOR EACH ROW BEGIN
    -- Validar que nombre_usuario no esté vacío
    IF NEW.nombre_usu IS NULL OR NEW.nombre_usu = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El nombre de usuario no puede estar vacío';
    END IF;

    -- Validar que usuario no esté vacío
    IF NEW.usuario IS NULL OR NEW.usuario = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El correo no puede estar vacío';
    END IF;

    -- Validar que clave no esté vacía
    IF NEW.contrasena IS NULL OR NEW.contrasena = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La clave no puede estar vacía';
    END IF;

    IF NEW.correo IS NULL OR NEW.correo = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La clave no puede estar vacía';
    END IF;
    
    IF NEW.documento IS NULL OR NEW.documento = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La clave no puede estar vacía';
    END IF;

    -- Si no se manda rol, asignar rol Cliente por defecto (id_rol = 1)
    IF NEW.cod_rol IS NULL THEN
        SET NEW.cod_rol = 676767;
    END IF;
IF NEW.cod_rol IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El usuario debe tener un rol asignado';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_AfterUpdateUsuarios` AFTER UPDATE ON `usuarios` FOR EACH ROW BEGIN
    INSERT INTO gestion_usu (
        fecha_modificacion,
        documento_old, documento_new,
        nom_usuold, nom_usunew,
        usuario_old, usuario_new,
        correo_old, correo_new,
        contrasena_old, contrasena_new,
        telefono_old, telefono_new,
        cod_rolold, cod_rolnew
    ) VALUES (
        NOW(),
        OLD.documento, NEW.documento,
        OLD.nombre_usu, NEW.nombre_usu,
        OLD.usuario, NEW.usuario,
        OLD.correo, NEW.correo,
        OLD.contrasena, NEW.contrasena,
        OLD.telefono, NEW.telefono,
        OLD.cod_rol, NEW.cod_rol
    );
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `cod_venta` int(12) NOT NULL,
  `documento` int(12) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `cantidad_venta` int(3) NOT NULL,
  `subtotal` decimal(12,4) NOT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `cod_inventario` int(12) NOT NULL,
  `cod_reserva` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Disparadores `ventas`
--
DELIMITER $$
CREATE TRIGGER `trg_venta_after_insert` AFTER INSERT ON `ventas` FOR EACH ROW BEGIN
    INSERT INTO venta_log (cod_venta, documento, cod_inventario, cod_reserva, cantidad_venta, subtotal, total, accion)
    VALUES (NEW.cod_venta, NEW.documento, NEW.cod_inventario, NEW.cod_reserva, NEW.cantidad_venta, NEW.subtotal, NEW.total, 'INSERT');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_venta_before_delete` BEFORE DELETE ON `ventas` FOR EACH ROW BEGIN
    INSERT INTO venta_log (
        cod_venta,
        documento,
        cod_inventario,
        cod_reserva,
        cantidad_venta,
        subtotal,
        total,
        accion
    )
    VALUES (
        OLD.cod_venta,
        OLD.documento,
        OLD.cod_inventario,
        OLD.cod_reserva,
        OLD.cantidad_venta,
        OLD.subtotal,
        OLD.total,
        'DELETE'
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_venta_before_update` BEFORE UPDATE ON `ventas` FOR EACH ROW BEGIN
    INSERT INTO venta_log (
        cod_venta,
        documento,
        cod_inventario,
        cod_reserva,
        cantidad_venta,
        subtotal,
        total,
        accion,
        cantidad_venta_anterior,
        documento_anterior
    )
    VALUES (
        OLD.cod_venta,
        OLD.documento,
        OLD.cod_inventario,
        OLD.cod_reserva,
        OLD.cantidad_venta,
        OLD.subtotal,
        OLD.total,
        'UPDATE',
        OLD.cantidad_venta,
        OLD.documento
    );
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta_log`
--

CREATE TABLE `venta_log` (
  `cod_ventalog` int(12) NOT NULL,
  `cod_venta` int(12) DEFAULT NULL,
  `documento` int(12) DEFAULT NULL,
  `cod_inventario` int(12) DEFAULT NULL,
  `cod_reserva` int(12) DEFAULT NULL,
  `cantidad_venta` int(11) DEFAULT NULL,
  `subtotal` decimal(12,4) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `accion` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `fecha_accion` timestamp NOT NULL DEFAULT current_timestamp(),
  `cantidad_venta_anterior` int(11) DEFAULT NULL,
  `documento_anterior` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_usuarios_roles`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_usuarios_roles` (
`documento` int(12)
,`nombre_usu` varchar(100)
,`correo` varchar(100)
,`telefono` varchar(15)
,`cod_rol` int(12)
,`nombre_rol` varchar(50)
,`descripcion_rol` text
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_horario_usuario`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vw_horario_usuario` (
`cod_horario` int(12)
,`fecha` date
,`hora` time
,`nombre_trabajador` varchar(100)
,`cargo` enum('Administrador','Cantinero','DJ','Cajero','Jalador','Portero','Mesero')
,`horas_trabajo` decimal(4,2)
,`nombre_usuario` varchar(100)
,`correo` varchar(100)
,`telefono` varchar(15)
,`cod_rol` int(12)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_inventario_producto_usuario`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vw_inventario_producto_usuario` (
`cod_inventario` int(12)
,`cod_producto` int(12)
,`nombre_prod` varchar(100)
,`categoria` varchar(50)
,`precio` decimal(10,2)
,`cantidad_producto` int(3)
,`documento` int(12)
,`nombre_usuario` varchar(100)
,`correo` varchar(100)
,`cod_rol` int(12)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_producto_usuario`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vw_producto_usuario` (
`cod_producto` int(12)
,`nombre_prod` varchar(100)
,`categoria` varchar(50)
,`precio` decimal(10,2)
,`documento` int(12)
,`Descripción_producto` varchar(200)
,`nombre_usuario` varchar(100)
,`correo` varchar(100)
,`cod_rol` int(12)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_usuarios_reservas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vw_usuarios_reservas` (
`documento` int(12)
,`nombre_usuario` varchar(100)
,`correo` varchar(100)
,`telefono` varchar(15)
,`cod_reserva` int(12)
,`Hora_Fecha` timestamp
,`tipo` enum('Mesa Vip','Mesa','Cover','Parqueadero')
,`estado` enum('Exitoso','Pendiente','Cancelado','')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_ventas_inventario`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vw_ventas_inventario` (
`cod_venta` int(12)
,`cantidad_venta` int(3)
,`subtotal` decimal(12,4)
,`total` decimal(10,2)
,`cod_inventario` int(12)
,`cod_producto` int(12)
,`nombre_prod` varchar(100)
,`categoria` varchar(50)
,`cantidad_disponible` int(3)
,`nombre_usuario` varchar(100)
,`email_usuario` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_ventas_reserva`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vw_ventas_reserva` (
`cod_venta` int(12)
,`documento_cliente` int(12)
,`nombre_cliente` varchar(100)
,`email_cliente` varchar(100)
,`cod_reserva` int(12)
,`fecha_reserva` timestamp
,`tipo_reserva` enum('Mesa Vip','Mesa','Cover','Parqueadero')
,`estado_reserva` enum('Exitoso','Pendiente','Cancelado','')
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_usuarios_roles`
--
DROP TABLE IF EXISTS `vista_usuarios_roles`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_usuarios_roles`  AS SELECT `u`.`documento` AS `documento`, `u`.`nombre_usu` AS `nombre_usu`, `u`.`correo` AS `correo`, `u`.`telefono` AS `telefono`, `u`.`cod_rol` AS `cod_rol`, `r`.`nombre` AS `nombre_rol`, `r`.`Descrip_rol` AS `descripcion_rol` FROM (`usuarios` `u` join `roles` `r` on(`u`.`cod_rol` = `r`.`cod_rol`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vw_horario_usuario`
--
DROP TABLE IF EXISTS `vw_horario_usuario`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_horario_usuario`  AS SELECT `h`.`cod_horario` AS `cod_horario`, `h`.`fecha` AS `fecha`, `h`.`hora` AS `hora`, `h`.`nombre_trabajador` AS `nombre_trabajador`, `h`.`cargo` AS `cargo`, `h`.`horas_trabajo` AS `horas_trabajo`, `u`.`nombre_usu` AS `nombre_usuario`, `u`.`correo` AS `correo`, `u`.`telefono` AS `telefono`, `u`.`cod_rol` AS `cod_rol` FROM (`horario` `h` join `usuarios` `u` on(`h`.`documento` = `u`.`documento`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vw_inventario_producto_usuario`
--
DROP TABLE IF EXISTS `vw_inventario_producto_usuario`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_inventario_producto_usuario`  AS SELECT `i`.`cod_inventario` AS `cod_inventario`, `i`.`cod_producto` AS `cod_producto`, `p`.`nombre_prod` AS `nombre_prod`, `p`.`categoria` AS `categoria`, `p`.`precio` AS `precio`, `i`.`cantidad_producto` AS `cantidad_producto`, `i`.`documento` AS `documento`, `u`.`nombre_usu` AS `nombre_usuario`, `u`.`correo` AS `correo`, `u`.`cod_rol` AS `cod_rol` FROM ((`inventario` `i` join `productos` `p` on(`i`.`cod_producto` = `p`.`cod_producto`)) join `usuarios` `u` on(`i`.`documento` = `u`.`documento`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vw_producto_usuario`
--
DROP TABLE IF EXISTS `vw_producto_usuario`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_producto_usuario`  AS SELECT `p`.`cod_producto` AS `cod_producto`, `p`.`nombre_prod` AS `nombre_prod`, `p`.`categoria` AS `categoria`, `p`.`precio` AS `precio`, `p`.`documento` AS `documento`, `p`.`Descripción_producto` AS `Descripción_producto`, `u`.`nombre_usu` AS `nombre_usuario`, `u`.`correo` AS `correo`, `u`.`cod_rol` AS `cod_rol` FROM (`productos` `p` join `usuarios` `u` on(`p`.`documento` = `u`.`documento`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vw_usuarios_reservas`
--
DROP TABLE IF EXISTS `vw_usuarios_reservas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_usuarios_reservas`  AS SELECT `u`.`documento` AS `documento`, `u`.`nombre_usu` AS `nombre_usuario`, `u`.`correo` AS `correo`, `u`.`telefono` AS `telefono`, `r`.`cod_reserva` AS `cod_reserva`, `r`.`Hora_Fecha` AS `Hora_Fecha`, `r`.`tipo` AS `tipo`, `r`.`estado` AS `estado` FROM (`usuarios` `u` join `reservas` `r` on(`u`.`documento` = `r`.`documento`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vw_ventas_inventario`
--
DROP TABLE IF EXISTS `vw_ventas_inventario`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_ventas_inventario`  AS SELECT `v`.`cod_venta` AS `cod_venta`, `v`.`cantidad_venta` AS `cantidad_venta`, `v`.`subtotal` AS `subtotal`, `v`.`total` AS `total`, `v`.`cod_inventario` AS `cod_inventario`, `i`.`cod_producto` AS `cod_producto`, `p`.`nombre_prod` AS `nombre_prod`, `p`.`categoria` AS `categoria`, `i`.`cantidad_producto` AS `cantidad_disponible`, `u`.`nombre_usu` AS `nombre_usuario`, `u`.`correo` AS `email_usuario` FROM (((`ventas` `v` join `inventario` `i` on(`v`.`cod_inventario` = `i`.`cod_inventario`)) join `productos` `p` on(`i`.`cod_producto` = `p`.`cod_producto`)) join `usuarios` `u` on(`i`.`documento` = `u`.`documento`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vw_ventas_reserva`
--
DROP TABLE IF EXISTS `vw_ventas_reserva`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_ventas_reserva`  AS SELECT `v`.`cod_venta` AS `cod_venta`, `v`.`documento` AS `documento_cliente`, `u`.`nombre_usu` AS `nombre_cliente`, `u`.`correo` AS `email_cliente`, `v`.`cod_reserva` AS `cod_reserva`, `r`.`Hora_Fecha` AS `fecha_reserva`, `r`.`tipo` AS `tipo_reserva`, `r`.`estado` AS `estado_reserva` FROM ((`ventas` `v` join `reservas` `r` on(`v`.`cod_reserva` = `r`.`cod_reserva`)) join `usuarios` `u` on(`v`.`documento` = `u`.`documento`)) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`cod_factura`),
  ADD KEY `cod_venta` (`cod_venta`),
  ADD KEY `documento` (`documento`);

--
-- Indices de la tabla `factura_log`
--
ALTER TABLE `factura_log`
  ADD PRIMARY KEY (`cod_facturalog`),
  ADD KEY `facturalog_factura` (`cod_factura`),
  ADD KEY `facturalog_usuario` (`documento`),
  ADD KEY `facturalog_venta` (`cod_venta`);

--
-- Indices de la tabla `gestion_usu`
--
ALTER TABLE `gestion_usu`
  ADD PRIMARY KEY (`cod-gestionusu`),
  ADD KEY `gestionusuario_usurio` (`documento`);

--
-- Indices de la tabla `horario`
--
ALTER TABLE `horario`
  ADD PRIMARY KEY (`cod_horario`),
  ADD KEY `horario_usuario` (`documento`);

--
-- Indices de la tabla `horario_log`
--
ALTER TABLE `horario_log`
  ADD PRIMARY KEY (`cod_horariolog`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`cod_inventario`),
  ADD KEY `inventario_producto` (`cod_producto`),
  ADD KEY `inventario_usuario` (`documento`);

--
-- Indices de la tabla `inventario_log`
--
ALTER TABLE `inventario_log`
  ADD PRIMARY KEY (`cod_inventariolog`),
  ADD KEY `inventariolog_inventario` (`cod_inventario`),
  ADD KEY `inventariolog_usuario` (`documento`),
  ADD KEY `inventariolog_producto` (`cod_producto`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`cod_producto`),
  ADD KEY `producto_usuario` (`documento`);

--
-- Indices de la tabla `producto_log`
--
ALTER TABLE `producto_log`
  ADD PRIMARY KEY (`cod_productolog`),
  ADD KEY `productolog_productos` (`cod_producto`),
  ADD KEY `prodcutolog_usuario` (`documento`);

--
-- Indices de la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`cod_reserva`),
  ADD KEY `reserva_usuario` (`documento`);

--
-- Indices de la tabla `reservas_log`
--
ALTER TABLE `reservas_log`
  ADD PRIMARY KEY (`cod_reservalog`),
  ADD KEY `reservalog_usuario` (`documento`),
  ADD KEY `reservalog_reserva` (`cod_reserva`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`cod_rol`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`documento`),
  ADD KEY `Rol_usuario` (`cod_rol`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`cod_venta`),
  ADD KEY `venta_usuario` (`documento`),
  ADD KEY `venta_inventario` (`cod_inventario`),
  ADD KEY `venta_reserva` (`cod_reserva`);

--
-- Indices de la tabla `venta_log`
--
ALTER TABLE `venta_log`
  ADD PRIMARY KEY (`cod_ventalog`),
  ADD KEY `ventalog_venta` (`cod_venta`),
  ADD KEY `ventalog_inventario` (`cod_inventario`),
  ADD KEY `ventalog_usuario` (`documento`),
  ADD KEY `ventalog_reserva` (`cod_reserva`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `cod_factura` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `factura_log`
--
ALTER TABLE `factura_log`
  MODIFY `cod_facturalog` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `gestion_usu`
--
ALTER TABLE `gestion_usu`
  MODIFY `cod-gestionusu` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `horario`
--
ALTER TABLE `horario`
  MODIFY `cod_horario` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `horario_log`
--
ALTER TABLE `horario_log`
  MODIFY `cod_horariolog` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `inventario_log`
--
ALTER TABLE `inventario_log`
  MODIFY `cod_inventariolog` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `producto_log`
--
ALTER TABLE `producto_log`
  MODIFY `cod_productolog` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `reservas`
--
ALTER TABLE `reservas`
  MODIFY `cod_reserva` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `reservas_log`
--
ALTER TABLE `reservas_log`
  MODIFY `cod_reservalog` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `venta_log`
--
ALTER TABLE `venta_log`
  MODIFY `cod_ventalog` int(12) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`cod_venta`) REFERENCES `ventas` (`cod_venta`) ON DELETE CASCADE,
  ADD CONSTRAINT `factura_ibfk_2` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`) ON DELETE CASCADE;

--
-- Filtros para la tabla `factura_log`
--
ALTER TABLE `factura_log`
  ADD CONSTRAINT `facturalog_factura` FOREIGN KEY (`cod_factura`) REFERENCES `factura` (`cod_factura`),
  ADD CONSTRAINT `facturalog_usuario` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`),
  ADD CONSTRAINT `facturalog_venta` FOREIGN KEY (`cod_venta`) REFERENCES `ventas` (`cod_venta`);

--
-- Filtros para la tabla `gestion_usu`
--
ALTER TABLE `gestion_usu`
  ADD CONSTRAINT `gestionusuario_usurio` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`);

--
-- Filtros para la tabla `horario`
--
ALTER TABLE `horario`
  ADD CONSTRAINT `horario_horariolog` FOREIGN KEY (`cod_horario`) REFERENCES `horario_log` (`cod_horariolog`),
  ADD CONSTRAINT `horario_usuario` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `inventario_producto` FOREIGN KEY (`cod_producto`) REFERENCES `productos` (`cod_producto`),
  ADD CONSTRAINT `inventario_usuario` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`);

--
-- Filtros para la tabla `inventario_log`
--
ALTER TABLE `inventario_log`
  ADD CONSTRAINT `inventariolog_inventario` FOREIGN KEY (`cod_inventario`) REFERENCES `inventario` (`cod_inventario`),
  ADD CONSTRAINT `inventariolog_producto` FOREIGN KEY (`cod_producto`) REFERENCES `productos` (`cod_producto`),
  ADD CONSTRAINT `inventariolog_usuario` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `producto_usuario` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`);

--
-- Filtros para la tabla `producto_log`
--
ALTER TABLE `producto_log`
  ADD CONSTRAINT `prodcutolog_usuario` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`),
  ADD CONSTRAINT `productolog_productos` FOREIGN KEY (`cod_producto`) REFERENCES `productos` (`cod_producto`);

--
-- Filtros para la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `reserva_usuario` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `reservas_log`
--
ALTER TABLE `reservas_log`
  ADD CONSTRAINT `reservalog_reserva` FOREIGN KEY (`cod_reserva`) REFERENCES `reservas` (`cod_reserva`),
  ADD CONSTRAINT `reservalog_usuario` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `Rol_usuario` FOREIGN KEY (`cod_rol`) REFERENCES `roles` (`cod_rol`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `venta_inventario` FOREIGN KEY (`cod_inventario`) REFERENCES `inventario` (`cod_inventario`),
  ADD CONSTRAINT `venta_reserva` FOREIGN KEY (`cod_reserva`) REFERENCES `reservas` (`cod_reserva`),
  ADD CONSTRAINT `venta_usuario` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`);

--
-- Filtros para la tabla `venta_log`
--
ALTER TABLE `venta_log`
  ADD CONSTRAINT `ventalog_inventario` FOREIGN KEY (`cod_inventario`) REFERENCES `inventario` (`cod_inventario`),
  ADD CONSTRAINT `ventalog_reserva` FOREIGN KEY (`cod_reserva`) REFERENCES `reservas` (`cod_reserva`),
  ADD CONSTRAINT `ventalog_usuario` FOREIGN KEY (`documento`) REFERENCES `usuarios` (`documento`),
  ADD CONSTRAINT `ventalog_venta` FOREIGN KEY (`cod_venta`) REFERENCES `ventas` (`cod_venta`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
