CREATE DATABASE log;

USE login_prueba;

CREATE TABLE usuarios (
    id int AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL,
    contraseña VARCHAR(200) NOT NULL,)

INSERT INTO usuarios (usuario, contraseña) VALUES ('admin', 'admin123');
