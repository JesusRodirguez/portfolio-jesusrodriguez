<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario Trabajador</title>
</head>
<body>
<form method="POST">
    <label>Nombre: </label>
    <input type="text" name="nombre" required><br><br>

    <label>Fecha Nacimiento: </label>
    <input type="date" name="nacimiento" required><br><br>

    <label>Correo electrónico: </label>
    <input type="email" name="correo" required><br><br>

    <label for="genero">Género: </label>
    <select name="genero" required>
        <option value="Hombre">Hombre</option>
        <option value="Mujer">Mujer</option>
        <option value="Otro">Otro</option>
    </select><br><br>

    <input type="submit" value="Enviar">
</form>

<?php
class Trabajador
{
    public $nombre;
    public $fenacimiento;
    public $correo;
    public $genero;

    public function __construct($nombre, $fenacimiento, $correo, $genero) {
        $this->nombre = htmlspecialchars($nombre);
        $this->fenacimiento = htmlspecialchars($fenacimiento);
        $this->correo = htmlspecialchars($correo);
        $this->genero = htmlspecialchars($genero);
    }

    public function mostrarInformacion() {
        $nacimiento = new DateTime($this->fenacimiento);
        $hoy = new DateTime();
        $edad = $hoy->diff($nacimiento)->y;

        $correoValido = str_contains($this->correo, "@gmail.com") && !str_contains($this->correo, " ");

        echo "<p>Hola <strong>{$this->nombre}</strong>, tienes <strong>{$edad}</strong> años, eres " . 
            ($edad < 18 ? "menor" : "mayor") . " de edad, tu género es <strong>{$this->genero}</strong>.</p>";

        if ($correoValido) {
            echo "<p>Tu correo es <strong>{$this->correo}</strong> y es válido.</p>";
        } else {
            echo "<p>Tu correo <strong>{$this->correo}</strong> es inválido.</p>";
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" &&
    isset($_POST['nombre']) &&
    isset($_POST['nacimiento']) &&
    isset($_POST['correo']) &&
    isset($_POST['genero'])) {

    $nombre = $_POST['nombre'];
    $nacimiento = $_POST['nacimiento'];
    $correo = $_POST['correo'];
    $genero = $_POST['genero'];

    $trabajador = new Trabajador($nombre, $nacimiento, $correo, $genero);
    $trabajador->mostrarInformacion();
}
?>
</body>
</html>