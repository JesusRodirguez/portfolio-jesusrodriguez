<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post">
        <input type="text" name="nombre" placeholder="Ingrese su nombre" required>
        <input type="number" name="edad" required>
        <input type="text" name="direccion" required>
        <input type="text" name="telefono" required>
        <input type="submit" value="enviar">
    </form>
        <?php
        class persona{
            public $nombre;
            public $edad;
            public $direccion;
            public $telefono;

            public function __construct($nombre, $edad, $direccion, $telefono){
                $this->nombre = $nombre;
                $this->edad = $edad;
                $this->direccion = $direccion;
                $this->telefono = $telefono;
            }
            public function mostrarDatos($nombre,$edad,$direccion,$telefono){
                if($nombre != null && $edad != null && $direccion != null){
                    if(is_numeric($telefono)&& strlen($telefono)===10){
                        echo "Nombre: $nombre <br>";
                        echo "Edad: $edad <br>";
                        echo "Direccion: $direccion <br>";
                        echo "Telefono: $telefono <br>";
                    }
                    else{
                        echo "Error: El telefono debe ser numerico";
                    }
                }

            }
        
        }
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $edad = $_POST['edad'] ?? '';
    $direccion = $_POST['direccion'] ?? '';
    $telefono = $_POST['telefono'] ?? '';

    if (!empty($nombre) && !empty($edad) && !empty($direccion) && !empty($telefono)) {
        $persona1 = new persona($nombre, $edad, $direccion, $telefono);
        $persona1->mostrarDatos($nombre, $edad, $direccion, $telefono);
    } else {
        echo "Por favor complete todos los campos.";
    }
}
        ?>
</body>
</html>