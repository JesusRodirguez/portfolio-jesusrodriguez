<?php
class producto
{
    public $nombre;
    public $precio;
    public $cantidad;
    public $expiracion;
    public $categoria;


    public function __construct($nombre, $precio, $cantidad, $categoria,$expiracion)
    {
        $this->nombre =htmlspecialchars($nombre);
//convierte a float el resultado
        $this->precio =floatval($precio);
//convierte a int el resultado
        $this->cantidad =intval($cantidad);
        $this->expiracion=($expiracion);
        $this->categoria = $categoria;
    }


    public function registro($expiracion)
    {
        $expiracion = new datetime($this->expiracion);
       $hoy= new DateTime();
       $fecha=$hoy->diff($expiracion)->d;
       echo "Hola trabajador, El nombre del producto es <strong>{$this->nombre}<strong/>","su precio es <strong>{$this->precio}<strong/>, su fecha de expiración es en <strong>{$fecha}<strong/> dias y su categoria es <strong>{$this->categoria}<strong/>, ";
      echo ($this->cantidad > 0
    ? "Hay {$this->cantidad} unidades disponibles."
    : "No hay unidades disponibles.");
    }
}
?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" &&
    isset($_POST['nombre']) &&
    isset($_POST['precio']) &&
    isset($_POST['cantidad']) &&
    isset($_POST['feexpiracion']) &&
    isset($_POST['categoria'])) {


    $nombre = $_POST['nombre'];
    $precio = $_POST['precio'];
    $cantidad = $_POST['cantidad'];
    $expiracion = $_POST['feexpiracion'];
    $categoria = $_POST['categoria'];


    $producto1 = new producto($nombre, $precio, $cantidad, $categoria,$expiracion);
    $producto1->registro($expiracion);
    }
?>