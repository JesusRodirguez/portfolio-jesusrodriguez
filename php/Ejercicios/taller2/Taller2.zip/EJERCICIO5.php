<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

<h2>Formulario de Trabajador</h2>
<form method="POST">
    <label for="nombre">Nombre:</label><br>
    <input type="text" name="nombre" id="nombre" required><br><br>

    <label for="horas">Horas trabajadas:</label><br>
    <input type="number" name="horas" id="horas" required><br><br>

    <label for="utilidades">Utilidades de la empresa (solo si es gerente):</label><br>
    <input type="number" name="utilidades"  step="0.01"><br><br>

    <button type="submit">Calcular sueldo</button>
</form>

<?php

abstract class Trabajador {
    protected $nombre;
    protected $sueldo;

    public function __construct($nombre)
    {
        $this->nombre = htmlspecialchars($nombre);
    }

    abstract public function calcularSueldo();

    public function imprimirDatos() 
    {
        echo "<p><strong>Nombre:</strong> $this->nombre <br>";
        echo "<strong>Sueldo:</strong> $" . number_format($this->sueldo, 2) . "</p>";
    }
}

class Empleado extends Trabajador {
    protected $horasTrabajadas;
    protected $valorHora = 3.50;

    public function __construct($nombre, $horasTrabajadas) 
    {
        parent::__construct($nombre);
        $this->horasTrabajadas = $horasTrabajadas;
    }

    public function calcularSueldo() 
    {
        $this->sueldo = $this->horasTrabajadas * $this->valorHora;
    }
}

class Gerente extends Empleado {
    private $utilidadesEmpresa;

    public function __construct($nombre, $horasTrabajadas, $utilidadesEmpresa) 
    {
        parent::__construct($nombre, $horasTrabajadas);
        $this->utilidadesEmpresa = $utilidadesEmpresa;
    }

    public function calcularSueldo() 
    {
        parent::calcularSueldo(); 
        $this->sueldo += $this->utilidadesEmpresa * 0.10; 
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["nombre"], $_POST["horas"])) {
    $nombre = $_POST["nombre"];
    $horas = floatval($_POST["horas"]);
    $utilidades = isset($_POST["utilidades"]) && $_POST["utilidades"] !== "" ? floatval($_POST["utilidades"]) : null;

    if ($utilidades !== null) {
        $trabajador = new Gerente($nombre, $horas, $utilidades);
    } else {
        $trabajador = new Empleado($nombre, $horas);
    }

    $trabajador->calcularSueldo();
    $trabajador->imprimirDatos();
}
?>

</body>
</html>