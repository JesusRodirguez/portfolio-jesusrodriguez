<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

<h2>Formulario de Empleado</h2>
<form method="POST">
    <label for="nombre">Nombre:</label><br>
    <input type="text" name="nombre" id="nombre" required><br><br>

    <label for="edad">Edad:</label><br>
    <input type="number" name="edad" id="edad" required><br><br>

    <label for="sueldo">Sueldo:</label><br>
    <input type="number" name="sueldo" id="sueldo" required><br><br>

    <button type="submit">Enviar</button>
</form>

<?php
class Persona {
    protected $nombre;
    protected $edad;

    public function cargarDatos($nombre, $edad) {
        $this->nombre = htmlspecialchars($nombre);
        $this->edad = intval($edad);
    }

    public function imprimirDatos() {
        echo "<p><strong>Nombre:</strong> {$this->nombre}<br>";
        echo "<strong>Edad:</strong> {$this->edad} años<br>";
    }
}

class Empleado extends Persona {
    private $sueldo;

    public function cargarSueldo($sueldo) {
        $this->sueldo = floatval($sueldo);
    }

    public function imprimirSueldo() {
        echo "<strong>Sueldo:</strong> $ {$this->sueldo}</p>";
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["nombre"], $_POST["edad"], $_POST["sueldo"])) {
    $empleado = new Empleado();
    $empleado->cargarDatos($_POST["nombre"], $_POST["edad"]);
    $empleado->cargarSueldo($_POST["sueldo"]);
    $empleado->imprimirDatos();
    $empleado->imprimirSueldo();
}
?>

</body>
</html>