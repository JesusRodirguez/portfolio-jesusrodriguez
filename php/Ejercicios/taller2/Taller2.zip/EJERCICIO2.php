<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>

<h2>Formulario de Empleado</h2>
<form method="POST">
    <label for="nombre">Nombre del empleado:</label><br>
    <input type="text" name="nombre" id="nombre" required><br><br>

    <label for="sueldo">Sueldo:</label><br>
    <input type="number" name="sueldo" id="sueldo" required><br><br>

    <button type="submit">Verificar</button>
</form>

<?php
class Empleado {
    private $nombre;
    private $sueldo;

    public function inicializar($nombre, $sueldo) 
    {
        $this->nombre = htmlspecialchars($nombre);
        $this->sueldo = $sueldo;
    }

    public function imprimirInformacion()
    {
        echo "<p><strong>{$this->nombre}</strong>: ";
        if ($this->sueldo > 3000) {
            echo "Debe pagar impuestos.</p>";
        } else {
            echo "No debe pagar impuestos.</p>";
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["nombre"], $_POST["sueldo"])) {
    $nombre = $_POST["nombre"];
    $sueldo = floatval($_POST["sueldo"]);

    $empleado = new Empleado();
    $empleado->inicializar($nombre, $sueldo);
    $empleado->imprimirInformacion();
}
?>

</body>
</html>
