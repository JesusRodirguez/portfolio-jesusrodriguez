<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <?php
    class CabeceraPagina 
    {
        private $titulo;
        private $alineacion;
        private $colorFondo;
        private $colorFuente;

        public function __construct($titulo, $alineacion, $colorFondo, $colorFuente)
        {
            $this->titulo = $titulo;
            $this->alineacion = $alineacion;
            $this->colorFondo = $colorFondo;
            $this->colorFuente = $colorFuente;
        }

        public function mostrar()
        {
            echo "<div style='
                background-color: {$this->colorFondo};
                color: {$this->colorFuente};
                text-align: {$this->alineacion};
                padding: 10px;
                font-weight: bold;
            '>{$this->titulo}</div>";
        }
    }

    $cabecera = new CabeceraPagina("Hola", "center", "#F0F0F0", "#CCC");
    $cabecera->mostrar();
    ?>
</body>
</html>