<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario con Clases PHP</title>
</head>
<body>

<form method="POST">
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" required>
    <button type="submit">Enviar</button>
</form>

<?php
class Persona 
{
    private $nombre;

    public function __construct($nom) 
    {
        $this->nombre = htmlspecialchars($nom);
    }

    public function imprimir(){
        echo "<p><strong>Nombre ingresado:</strong> " . $this->nombre . "</p>";
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && !empty($_POST["nombre"])) {
    $nombre = $_POST["nombre"];
    $persona = new Persona($nombre);
    $persona->imprimir();
}
?>

</body>
</html>