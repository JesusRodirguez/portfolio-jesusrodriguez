<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Hola</h1>
    <form method="POST">
        <label> Coloca el nombre plis</label>
        <!-- preg_match esto funciona para preguntar si tiene un nombre con los caracteres o no los tiene en el nombre -->
        <input type="text" name="nombre" placeholder="Nombre solamente, plis" required title="Solo letras, nada de numeros"  pattern="[A-Za-záéíóúÁÉÍÓÚñÑ\s]+" >
        <label>¿quieres,que te haga la clave?</label>
        <input type="text" name="clave" placeholder="Solo Si o No, por favor" required >
        <input type="submit" value="enviar">
    </form>
        <?php
        class usuario{
            public $nombre;
            public $clave;

            public function __construct($nombre, $clave){
                $this->nombre = $nombre;
                $this->clave = $clave;
            }
            public function clave($clave,$nombre){
                // strtoupper( Pone todos los resultados en mayuscula y lo de strtolower en minusculas)
                if(strtoupper($clave)==='SI'){
                    for($i=0;$i<8;$i++)$clave .= chr(rand(48,57));
                    for($i=0;$i<5;$i++)$clave .= chr(rand(65,90));
                    for($i=0;$i<5;$i++)$clave .= chr(rand(97,122));
                    
                    // str_shuffle funciona para cambiar  de lugar los caracteres de la clave
                    $clave = str_shuffle($clave);

                    echo("Hola {$nombre}, tu clave es {$clave}");
                }
                if(strtolower($clave)==='no'){
                    echo ("okey brother, {$nombre}. Hasta Luego ");
                }
            }
        }
        if($_SERVER['REQUEST_METHOD'] === 'POST'
        && isset ($_POST['nombre'])
        && isset ($_POST['clave'])){
            $nombre = htmlspecialchars($_POST['nombre']);
            $clave = ($_POST['clave']);

            $usuario_nuevo = new usuario($nombre, $clave);
            $usuario_nuevo->clave($clave,$nombre,);
        }
        ?>
</body>
</html>