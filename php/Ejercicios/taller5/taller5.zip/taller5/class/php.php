<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>class</title>
</head>
<body>
    <form method="post">
        <label>¿Como te llamas?</label><br>
        <input type="text" name="nombre"><br><br>
        <label>Nombre del Producto</label><br>
        <input type="text" name="Nom_producto"><br><br>
        <label>Cantidad</label><br>
        <input type="number" name="Cantidad_producto">
        <input type="submit" value="Guardar">
    </form>
<?php

class producto{
    public $nombre;
    public $Nom_producto;
    public $Cantidad_producto;


public function __construct($nombre,$Nom_producto,$Cantidad_producto){
    $this->nombre=$nombre;
    $this->Nom_producto=$Nom_producto;
    $this->Cantidad_producto=$Cantidad_producto;
    }

public function AgregarProducto(){
        echo "Producto agregado";
    }

}
?>
<?php
if($_SERVER["REQUEST_METHOD"] == "POST" &&
isset($_POST["nombre"]) &&
isset($_POST["Nom_producto"]) &&
isset($_POST["Cantidad_producto"])){
    $nombre = htmlspecialchars($_POST["nombre"]);
    $Nom_producto = htmlspecialchars($_POST["Nom_producto"]);
    $Cantidad_producto =intval($_POST["Cantidad_producto"]);
    $producto = new producto($nombre,$Nom_producto,$Cantidad_producto);
    $producto->AgregarProducto();
}
?>
</body>
</html>
