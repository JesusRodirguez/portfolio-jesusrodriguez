import Login from './componentes/login';
import './index.css'
import NavBar from './componentes/NavBar'
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
const Home = () => <h2 className="text-center mt-10 text-white">Página de inicio</h2>;
// const Login = () => <h2 class="text-center mt-10 text-white">Página de inicio de sesión</h2>;

function App() {
  const location = useLocation();

  const hidenavBar = location.pathname === "/login";
  return (
    <>
      {!hidenavBar && <NavBar />}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </>
  )
}
export default App;
