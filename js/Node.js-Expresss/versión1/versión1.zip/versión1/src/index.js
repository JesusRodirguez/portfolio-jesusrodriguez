const express = require('express')
const app = express()

let users = [
    {
        id : 1,
        user:"Juan",
    },
    {
        id:2,
        user:"Maria",
    },
]

app.get('/',(request,response) =>{
    response.send('<h1>Servidor con spresss</h1>')
})

app.get('/api/users',(request,response) =>{
    response.json(users)
})

app.get('/api/users/:id',(request,response) =>{
     // Extraer el parámetro de la URL
  const id = Number(request.params.id);

  // Buscar el usuario en el arreglo
  const user = users.find(u => u.id === id);

  // Si no existe, responder con un mensaje y estado 404
  if (!user) {
    return response.status(404).json({ message: 'Usuario no encontrado' });
  }

  // Si existe, responder con ese usuario
  response.json(user);
})

const PORT = 3001
app.listen(PORT,() => {
    console.log('segundo servidor en el puerto http://localhost:3001')
})
