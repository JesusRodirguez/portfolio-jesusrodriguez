const { request, response } = require('express')

const http = require('http')



const server= http.createServer((request,response)=>{
    response.writeHead(200, { 'Content-Type': 'text/plain' });
    response.end('¡Hola servidor! Node.js está funcionando ');
})

server.listen(3000, () => {
  console.log('Servidor corriendo en http://localhost:3000');
});