const express = require('express')
const app = express()
app.use((express.json))

let users = [
    {
        id : 1,
        user : "Juan",
        edad : 18,
        numero:2,
    },
    {
        id :2,
        user : "Migel",
        edad : 22,
        numero : 3,
    },
    {
        id :3,
        user : "Leo",
        edad : 18,
        numero : 5,
    },
    {
        id :4,
        user : "Josue",
        edad : 22,
        numero :8,
    },
    {
        id :5,
        user : "Maria",
        edad :18,
        numero :10,
    },
]

app.get('/',(request,response) =>{
    response.send('<h1>Primer Servidor utilizando expresss</h1>')
})

app.get('/api/usersdic',(request,response) =>{
    response.json(users)
})

app.get('/api/usersdic/:id',(request,response) =>{
    const id = Number(request.params.id);

    const user = users.find(p => p.id === id);

    if(!user){
        return response.status(404).json({mensage : 'El usuario no se encontro'});
    }

    response.json(user);
})
app.put('/api/users/:id',(request,response)=>{
    const id = Number(request.params.id);
    const user = users.find(p => p.id === id);

    if(!user){
        return response.status(404).json('No se encontro el usuario');
    }

    user.user = "Migel";
    user.edad = 40;
    user.numero = 30;

    response.status(200).json({mensaje: "Actualizado correctamente", usuario : user});
})
app.delete('/api/users/:id',(request,response)=>{
    const id = Number(request.params.id);
    const index = users.findIndex(p => p.id === id); 
    //findIndex hace que busque el lugar donde se encuentra posicionado el usuario.

    if(index === -1){
        return response.status(404).json('usuario no encontrado');
    }
    const eliminado = users.splice(index,1)

    response.status(200).json({mensaje: "Eliminado completamente correctamente", usuario : eliminado[0]});
})

app.get('/api/usersdic',(request,response) =>{
    response.json(users)
})

app.get('/api/users/:numero',(request,response) =>{
    const numero = Number(request.params.numero);
    const resultado = users.filter(p => p.numero === numero)           // filtra los que coinciden
    .map(p => ({...p,resultado: p.numero * p.numero}));        // multiplica por sí misma y duplica el ... parametro,
    if(resultado.length === 0){
        return response.status(404).json({mensage : 'El numero ningun objeto lo tiene'});
    }

    response.json(resultado);
})

app.get('/api/usersmap/:edad',(request,response) =>{
    const edad = Number(request.params.edad);

    const person = users.filter(p => p.edad === edad);

    if(person.length === 0){
        return response.status(404).json({mensage : 'El usuario tiene otra edad'});
    }

    response.json(person);
})

app.post('/api/user/agregar',(request,response)=>{
    // const nuevoUsuario = request.body; //ESTA LINEA FUNCIONA PARA ALMACENAR LO QUE RECIBA DEL FORMULARIO
    const nuevoUsuario = { id:30,user:"Paco",edad:45,numero:12};
    users.push(nuevoUsuario); // ESTA LA AGREGA A LA RAY 
    response.status(201).json({Mensaje : "Agregado un nuevo usuario", usuarios : users}); // MUESTRA UN MENSAJE 
})
const PORT = 3002

app.listen(PORT,() =>{
    console.log('El servidor fue creado y funciona con tranquilidad en http://localhost:3002')
})