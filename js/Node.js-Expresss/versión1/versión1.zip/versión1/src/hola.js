const server = require('express')
const app = express()
app.use((express.json))



app.get('/',(require,response)=>{
    response.send('<h1>Hola</h1>')
});

const PORT = 3001
app.listen(PORT,()=>{
    console.log('El servidor fue creado y funciona con tranquilidad en http://localhost:3001')
})
